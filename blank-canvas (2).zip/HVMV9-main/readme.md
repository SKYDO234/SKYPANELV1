apt update 

apt install git

git clone https://github.com/DreamHost2ws/HVMV9

cd HVMV9 && cd hvm

apt install python3

lxd init 

enter all

python3 hvm.py
