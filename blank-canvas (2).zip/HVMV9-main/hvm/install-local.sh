#!/usr/bin/env bash
# ==============================================================================
#  SKY PANEL Local Installation & Execution Script
#  Enables full-stack local execution on http://localhost:5060
# ==============================================================================

set -e

# Color definitions
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
NC='\033[0m' # No Color

echo -e "${BLUE}${BOLD}======================================================================${NC}"
echo -e "${CYAN}${BOLD}                 SKY PANEL - LOCAL INSTALLATION & STARTUP              ${NC}"
echo -e "${BLUE}${BOLD}======================================================================${NC}"
echo ""

# Ensure run as root/sudo
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}${BOLD}[ERROR] This script must be run with sudo or as root to install system packages.${NC}"
    echo -e "${YELLOW}Please run: sudo bash $0${NC}"
    exit 1
fi

# Detect absolute directories
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
REACT_DIR="$SCRIPT_DIR"
PYTHON_DIR="$SCRIPT_DIR/HVMV9-main/hvm"

# Validate directories
if [ ! -f "$REACT_DIR/package.json" ]; then
    # Maybe we are in HVMV9-main/hvm/
    if [ -f "$SCRIPT_DIR/../../package.json" ]; then
        REACT_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
        PYTHON_DIR="$(cd "$SCRIPT_DIR" && pwd)"
    else
        echo -e "${RED}${BOLD}[ERROR] Could not locate the package.json file of the panel workspace.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}[1/7] Updating and upgrading system packages...${NC}"
apt-get update && apt-get upgrade -y

echo -e "\n${GREEN}[2/7] Installing Python 3, pip, and virtual environment utilities...${NC}"
apt-get install -y python3 python3-pip python3-venv python3-dev build-essential

echo -e "\n${GREEN}[3/7] Installing LXC, LXD, and network/bridge prerequisites...${NC}"
# LXC installation
apt-get install -y lxc lxc-templates bridge-utils iptables dnsmasq curl wget || true

# LXD installation via snap (standard for modern Ubuntu/Debian)
if command -v snap >/dev/null 2>&1; then
    echo -e "${CYAN}Snap is available. Installing/ensuring LXD via snap...${NC}"
    snap install lxd || true
else
    echo -e "${CYAN}Snap not found. Attempting LXD install via apt...${NC}"
    apt-get install -y lxd || true
fi

# Try to initialize LXD if not already initialized
if command -v lxd >/dev/null 2>&1; then
    echo -e "${CYAN}Checking LXD initialization status...${NC}"
    if ! lxd init --auto >/dev/null 2>&1; then
        echo -e "${YELLOW}LXD is not initialized or failed auto-initialization. You may need to run 'lxd init' manually later.${NC}"
    else
        echo -e "${GREEN}LXD auto-initialized successfully.${NC}"
    fi
fi

echo -e "\n${GREEN}[4/7] Installing Node.js & npm...${NC}"
if ! command -v npm >/dev/null 2>&1; then
    echo -e "${CYAN}npm not found. Installing Node.js and npm via apt...${NC}"
    apt-get install -y nodejs npm
else
    echo -e "${CYAN}npm already installed: $(npm -v)${NC}"
fi

echo -e "\n${GREEN}[5/7] Installing React/Vite development dependencies (npm install)...${NC}"
echo -e "${CYAN}Navigating to: $REACT_DIR${NC}"
cd "$REACT_DIR"
npm install --no-audit --no-fund

echo -e "\n${GREEN}[6/7] Installing Python dependencies (pip)...${NC}"
echo -e "${CYAN}Navigating to: $PYTHON_DIR${NC}"
cd "$PYTHON_DIR"

# Explicitly install pip via apt as requested by the user
echo -e "${CYAN}Installing pip via apt...${NC}"
apt-get install -y python3-pip || apt-get install -y pip || apt install -y python3-pip || apt install -y pip || true

# Ensure pip is up to date
python3 -m pip install --upgrade pip --break-system-packages || python3 -m pip install --upgrade pip || true

# Install requirements
if [ -f "requirements.txt" ]; then
    echo -e "${CYAN}Installing packages from requirements.txt...${NC}"
    pip3 install -r requirements.txt --break-system-packages || pip3 install -r requirements.txt || pip install -r requirements.txt || true
else
    echo -e "${YELLOW}Warning: requirements.txt not found. Installing core Flask/SocketIO dependencies manually...${NC}"
    pip3 install Flask flask-cors Flask-Login Flask-SocketIO eventlet gevent gevent-websocket paramiko pillow psutil python-dotenv requests cryptography --break-system-packages || \
    pip3 install Flask flask-cors Flask-Login Flask-SocketIO eventlet gevent gevent-websocket paramiko pillow psutil python-dotenv requests cryptography || true
fi

echo -e "\n${GREEN}[7/7] Launching SKY PANEL on http://localhost:5060...${NC}"
echo -e "${CYAN}Host: localhost (127.0.0.1)${NC}"
echo -e "${CYAN}Port: 5060${NC}"
echo -e "${CYAN}Database Path: $PYTHON_DIR/hvm.db${NC}"

# Configure execution environment variables
export HOST="127.0.0.1"
export PORT="5060"
export DATABASE_PATH="$PYTHON_DIR/hvm.db"

# Change directory to the python panel folder
cd "$PYTHON_DIR"

# Start Python Flask socket server
echo -e "${BLUE}${BOLD}======================================================================${NC}"
echo -e "${GREEN}${BOLD}        SKY PANEL IS NOW RUNNING ON: http://localhost:5060             ${NC}"
echo -e "${BLUE}${BOLD}======================================================================${NC}"
echo ""

python3 hvm.py
